package com.example.jabir_shabbir.androiddashplayer;

/**
 * Created by Jabir_shabbir on 27-09-2015.
 */
public class HTTPRequests
{
    long requestSentTime;
    long requestFirstSentTime;
    int requestNo;
    long expiryTime;
    String quality;
    int segmentSize;
    int requestType;
    int requestFailType=-1;
}
